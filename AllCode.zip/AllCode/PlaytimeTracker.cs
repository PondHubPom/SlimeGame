using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlaytimeTracker : MonoBehaviour
{
    public int playtime;
    public TextMeshProUGUI timeText;
    public TextMeshProUGUI goldText;
    private int seconds;
    private int minutes;
    private int hours;
    private int days;
    private int gold;

    void Start()
    {
        StartCoroutine ("Playtimer");
    }

    private IEnumerator Playtimer()
    {
        while(true)
        {
            yield return new WaitForSeconds(1);
            playtime += 1;
            int seconds = (playtime % 60);
            int minutes = (playtime / 60) % 60;
            int hours = (playtime / 3600) % 24;
            int days = (playtime / 86400) % 365;
            timeText.text = string.Format("{0} Days {1} Hours {2} Minutes {3} Seconds", days, hours, minutes, seconds);
            goldText.text = (int)minutes + "g";
            gold = (int)minutes;
        }
    }
    public void Get()
    {
        SaveManager.instance.focusPoint += gold;
        SaveManager.instance.Save();
        playtime = 0;
    }
}