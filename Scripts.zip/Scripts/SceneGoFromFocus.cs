using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneGoFromFocus : MonoBehaviour
{
    public void GotoGame ()
    {
        SceneManager.LoadScene(1);
    }
}
