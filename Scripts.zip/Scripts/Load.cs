using UnityEngine;
using UnityEngine.SceneManagement;

public class Load : MonoBehaviour
{
    public void LoadLevelNumber()
    {
        SceneManager.LoadScene(1);
    }
}