using UnityEngine;
using UnityEngine.PlayerLoop;
using UnityEngine.UI;
using TMPro;

public class SlimeSelection : MonoBehaviour
{
    [Header ("Navigation Buttons")]
    [SerializeField] private Button previousButton;
    [SerializeField] private Button nextButton;

    [Header("Play/Buy Buttons")]
    [SerializeField] private Button play;
    [SerializeField] private Button buy;
    [SerializeField] private TextMeshProUGUI priceText;

    [Header("Slime Attributes")]
    [SerializeField] private int[] slimePrices;
    private int CurrentSlime;

    [Header("Sound")]
    [SerializeField] private AudioClip purchase;
    private AudioSource source;

    private void Start()
    {
        source = GetComponent<AudioSource>();
        CurrentSlime = SaveManager.instance.CurrentSlime;
        SelectSlime(CurrentSlime);
    }

    private void SelectSlime(int _index)
    {
        for (int i = 0; i < transform.childCount; i++)
            transform.GetChild(i).gameObject.SetActive(i == _index);

        UpdateUI();
    }
    private void UpdateUI()
    {
        if (SaveManager.instance.SlimeUnlocked[CurrentSlime])
        {
            play.gameObject.SetActive(true);
            buy.gameObject.SetActive(false);
        }
        else
        {
            play.gameObject.SetActive(false);
            buy.gameObject.SetActive(true);
            priceText.text = slimePrices[CurrentSlime] + "g";
        }
    }

    private void Update()
    {
        if (buy.gameObject.activeInHierarchy)
            buy.interactable = (SaveManager.instance.focusPoint >= slimePrices[CurrentSlime]);
    }

    public void ChangeSlime(int _change)
    {
        CurrentSlime += _change;

        if (CurrentSlime > transform.childCount - 1)
            CurrentSlime = 0;
        else if (CurrentSlime < 0)
            CurrentSlime = transform.childCount - 1;

        SaveManager.instance.CurrentSlime = CurrentSlime;
        SaveManager.instance.Save();
        SelectSlime(CurrentSlime);
    }
    public void BuySlime()
    {
        SaveManager.instance.focusPoint -= slimePrices[CurrentSlime];
        SaveManager.instance.SlimeUnlocked[CurrentSlime] = true;
        SaveManager.instance.Save();
        source.PlayOneShot(purchase);
        UpdateUI();
    }
}