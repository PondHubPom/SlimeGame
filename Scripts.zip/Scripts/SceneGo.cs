using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneGo : MonoBehaviour
{

    public void GotoFocus ()
    {
        SceneManager.LoadScene(2);
    }
    public void GotoCus()
    {
        SceneManager.LoadScene(2);
    }
    public void GotoMore()
    {
        SceneManager.LoadScene(2);
    }
    public void GotoMain ()
    {
        SceneManager.LoadScene(0);
    }
}
