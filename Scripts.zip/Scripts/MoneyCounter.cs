﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MoneyCounter : MonoBehaviour
{
    public TextMeshProUGUI moneytext;

    void Update()
    {
        moneytext.text = SaveManager.instance.focusPoint + " g";
    }
}