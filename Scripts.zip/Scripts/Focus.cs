using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using TMPro;

public class Focus : MonoBehaviour
{
    public TextMeshProUGUI goldText;
    public TextMeshProUGUI timeText;

    void Start()
    {
        if (PlayerPrefs.HasKey("LAST_LOGIN"))
        {
            DateTime lastLogIn = DateTime.Parse(PlayerPrefs.GetString("LAST_LOGIN"));

            TimeSpan ts = DateTime.Now - lastLogIn;
            
            timeText.text = string.Format("{0} Days {1} Hours {2} Minutes {3} Seconds Ago", ts.Days, ts.Hours, ts.Minutes, ts.Seconds);
            goldText.text = (int)ts.TotalMinutes + "g";

            SaveManager.instance.focusPoint = (int)ts.TotalMinutes;
            SaveManager.instance.Save();
        }
        else
        {
            timeText.text = "WELCOME";
            goldText.text = "0g";
        }
    }

    private void OnApplicationQuit()
    {
        PlayerPrefs.SetString("LAST_LOGIN",DateTime.Now.ToString());
    }
}
